"""
A collection of custom fractal tasks.
"""
